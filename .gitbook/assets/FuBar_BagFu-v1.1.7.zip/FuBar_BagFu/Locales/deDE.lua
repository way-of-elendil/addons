local L = AceLibrary("AceLocale-2.2"):new("FuBar_BagFu")

L:RegisterTranslations("deDE", function() return {
	["Ammo/Soul Bags"] = "Munition/Seelen Taschen",
	["Profession Bags"] = "Berufe Taschen",
	["Bag Depletion"] = "Taschen Entleerung",
	["Include ammo/soul bags"] = "Munition/Seelen Taschen mit einbeziehen",
	["Include profession bags"] = "Spezialtaschen f\195\188r Berufe einbeziehen",
	["Show depletion of bags"] = "Zeige freie Pl\195\164tze",
	["Bag Total"] = "Taschen Gesamt",
	["Show total amount of space in bags"] = "Zeige Gesamtanzahl an Taschenpl\195\164tzen",

	["Click to open your bags"] = "Linksklick \195\182ffnet die Taschen"
} end)
