﻿local L = AceLibrary("AceLocale-2.2"):new("FuBar_BagFu")

L:RegisterTranslations("koKR", function() return {
	["Ammo/Soul Bags"] = "탄약/영혼석 가방",
	["Profession Bags"] = "전문기술 가방",
	["Bag Depletion"] = "빈 슬롯 표시",
	["Include ammo/soul bags"] = "탄약/영혼석 가방 포함",
	["Include profession bags"] = "슬롯의 수를 계산할 때 전문기술 가방을 포함합니다",
	["Show depletion of bags"] = "가방의 사용 중인 슬롯의 수 대신에 빈 슬롯의 수를 표시합니다",
	["Bag Total"] = "총 슬롯수",
	["Show total amount of space in bags"] = "가방안의 총 슬롯의 수를 표시합니다",

	["Click to open your bags"] = "클릭시 가방 열기",

	["Open Bags at Bank"] = "은행 방문시 가방열기",
	["Open all of your bags when you're at the bank"] = "은행을 클릭했을 때 모든 가방을 자동으로 엽니다.",
	["Open Bags at Vendor"] = "상인 방문시 가방열기",
	["Open all of your bags when you're at a vendor"] = "상인을 클릭했을 때 모든 가방을 자동으로 엽니다.",
} end)
