﻿local L = AceLibrary("AceLocale-2.2"):new("FuBar_BagFu")

L:RegisterTranslations("ruRU", function() return {
	["Ammo/Soul Bags"] = "Сумка с патронами/с душами",
	["Profession Bags"] = "Сумки профессий",
	["Bag Depletion"] = "Оставшееся место",
	["Include ammo/soul bags"] = "Отслеживать сумки с боеприпасами и душами",
	["Include profession bags"] = "Отслеживать сумки различных професиий",
	["Show depletion of bags"] = "Показывать оставшееся количество свободных ячеек",
	["Bag Total"] = "Всего ячеек",
	["Show total amount of space in bags"] = "Показывать общее количество ячеек в сумках",

	["Click to open your bags"] = "Кликните, чтобы открыть ваши сумки",
	
	["Open Bags at Bank"] = "Открывать сумки в банке",
	["Open all of your bags when you're at the bank"] = "Открыть все ваши сумки, когда вы открываете банковскую ячейку",
	["Open Bags at Vendor"] = "Открывать сумки у торговца",
	["Open all of your bags when you're at a vendor"] = "Открыть все ваши сумки, когда вы совершаете сделку у торговца",
} end)
