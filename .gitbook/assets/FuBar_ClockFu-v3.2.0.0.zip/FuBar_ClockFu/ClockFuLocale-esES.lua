local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_ClockFu")
L:AddTranslations("esES", function() return {
	["24-hour format"] = "Formato de 24 horas",
	["Toggle between 12-hour and 24-hour format"] = "Cambia entre formato de 12 y 24 horas",
	["Show seconds"] = "Mostrar segundos",
	["Local time"] = "Hora local",
	["Toggle between local time and server time"] = "Cambia entre hora local y hora del servidor",
	["Both times"] = "Ambas horas",
	["Toggle between showing two times or just one"] = "Cambia entre mostrar las dos horas o solo una",
	["Show day/night bubble"] = "Mostrar la burbuja de d\195\173a/noche",
	["Show the day/night bubble on the upper-right corner of the minimap"] = "Muestra la burbuja de d\195\173a/noche en la esquina superior derecha del minimapa",
	["Set the color of the text"] = "Establece el color del texto",
	
	["AceConsole-commands"] = { "/clockfu" },
	
	["Server time"] = "Hora del servidor",
	["UTC"] = "UTC",

	["DATE"] = "%A, %d %B, %Y",

} end)