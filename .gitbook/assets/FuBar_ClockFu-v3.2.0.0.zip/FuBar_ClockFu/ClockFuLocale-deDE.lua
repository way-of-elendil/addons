local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_ClockFu")
L:AddTranslations("deDE", function() return {
	["24-hour format"] = "24-Stunden-Format",
	["Toggle between 12-hour and 24-hour format"] = "Zwischen 12- und 24-Stunden-Format umschalten.",
	["Show seconds"] = "Sekunden anzeigen",
	["Local time"] = "Lokale Zeit",
	["Toggle between local time and server time"] = "Zwischen lokaler und Serverzeit umschalten.",
	["Both times"] = "Sowohl Server-, als auch lokale Zeit anzeigen",
	["Toggle between showing two times or just one"] = "Umschalter f�r einfache oder doppelte Zeitanzeige.",
	["Show day/night bubble"] = "Tag/Nacht-Anzeige ein/ausschalten",
	["Show the day/night bubble on the upper-right corner of the minimap"] = "Zeige die Tag/Nacht-Anzeige oben rechts an der Minikarte.",
	["Show minimap clock"] = "Uhrzeit an Minikarte anzeigen",
	["Show small Blizzard clock below minimap"] = "Zeigt oder versteckt Blizzard's Zeit unter der Minikarte.",
	
	["Set the color of the text"] = "Sie die Farbe des Textes ein",
	
	["AceConsole-commands"] = { "/clockfu" },
	
	["Server time"] = "Serverzeit",
	["UTC"] = "UTC"
} end)