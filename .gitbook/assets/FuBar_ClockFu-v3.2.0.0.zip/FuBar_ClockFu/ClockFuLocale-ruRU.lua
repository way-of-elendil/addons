﻿local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_ClockFu")
local WEEK = {
	["Sunday"] = "|CFFFF1100Воскресенье|r",
	["Monday"] = "Понедельник",
	["Tuesday"] = "Вторник",
	["Wednesday"] = "|CFF115599Среда|r",
	["Thursday"] = "Четверг",
	["Friday"] = "Пятница|r",
	["Saturday"] = "|CFFFF1100Суббота|r",
}

L:AddTranslations("ruRU", function() return {
	["24-hour format"] = "24-часовой формат",
	["Toggle between 12-hour and 24-hour format"] = "Переключение между 12-часовым и 24-часовым форматами",
	["Show seconds"] = "Показывать секунды",
	["Local time"] = "Местное время",
	["Toggle between local time and server time"] = "Переключение между местным временем и временем сервера",
	["Both times"] = "Оба времени",
	["Toggle between showing two times or just one"] = "Переключение между отображением двух часов или только одних",
	["Show day/night bubble"] = "Показывать индикатор дня/ночи",
	["Show the day/night bubble on the upper-right corner of the minimap"] = "Отображение индикатора дня/ночи в правом верхнем углу миникарты",
	["Show minimap clock"] = "Показывать часы на миникарте",
	["Show small Blizzard clock below minimap"] = "Отображение маленьких часов под миникартой",
	
	["Set the color of the text"] = "Установка цвета текста",
	
	["AceConsole-commands"] = { "/clockfu" },
	
	["Server time"] = "Время сервера",
	["UTC"] = "Универсальное время",

	["DATE"] = function() return date("%d/%m/%Y (")..WEEK[date("%A")]..")" end

} end)