local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_ClockFu")

local WEEK = {
	["Sunday"] = "|CFFFF1100星期日|r",
	["Monday"] = "星期一",
	["Tuesday"] = "星期二",
	["Wednesday"] = "星期三",
	["Thursday"] = "星期四",
	["Friday"] = "星期五",
	["Saturday"] = "|CFF115599星期六|r",
}

L:AddTranslations("zhTW", function() return {
	["24-hour format"] = "24小時制",
	["Toggle between 12-hour and 24-hour format"] = "切換時間格式為12小時或24小時",
	["Show seconds"] = "顯示秒",
	["Local time"] = "顯示本地時間",
	["Toggle between local time and server time"] = "切換顯示伺服器時間或本地時間",
	["Both times"] = "同時顯示2個時間",
	["Toggle between showing two times or just one"] = "切換同時顯示2個時間或只顯示1個時間",
	["Show day/night bubble"] = "顯示白天/夜晚圖示",
	["Show the day/night bubble on the upper-right corner of the minimap"] = "顯示白天/夜晚圖示在小地圖上",
	["Set the color of the text"] = "設定文字顯示顏色",
    ["Show minimap clock"] = "顯示小地圖時鐘",
    ["Show small Blizzard clock below minimap"] = "在小地圖上顯示 Blizzard 時鐘",

    ["AceConsole-commands"] = { "/clockfu" },
	
	["Server time"] = "伺服器時間",
	["UTC"] = "世界標準時間（UTC）",

	["DATE"] = function() return date("%Y年 %m月 %d日 (")..WEEK[date("%A")]..")" end

} end)