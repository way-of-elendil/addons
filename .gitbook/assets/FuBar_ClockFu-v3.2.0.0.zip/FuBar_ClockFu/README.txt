FuBar - ClockFu v3.0

Author: ckknight (ckknight@gmail.com)
$Date: 2007-09-25 02:26:10 +0000 (Tue, 25 Sep 2007) $

A simplistic clock.

TO INSTALL: Put the FuBar_ClockFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures
