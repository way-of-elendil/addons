--~ local deformat = AceLibrary("Deformat-2.0")
local tablet = AceLibrary("Tablet-2.0")
local L = AceLibrary("AceLocale-2.2"):new("FuBar_FactionsFu")

local _G = getfenv(0)

local select			= _G.select

local table_insert		= _G.table.insert
local table_remove		= _G.table.remove
local table_sort		= _G.table.sort

local GetFactionInfo			= GetFactionInfo
local GetWatchedFactionInfo		= GetWatchedFactionInfo

local watchedID = nil
local function GetWatchedFactionFullInfo()
	local watchedName = GetWatchedFactionInfo()
	if not watchedName then
		watchedID = nil
		return
	end
	if watchedID and GetFactionInfo(watchedID) == watchedName then
		-- we have an ID cached and it's still correct
		return GetFactionInfo(watchedID)
	end

	local factionIndex = 1
	local lastFactionName
	repeat
		local name = GetFactionInfo(factionIndex)
		if name == lastFactionName then break end
		lastFactionName  = name
		if name == watchedName then
			watchedID = factionIndex
			return GetFactionInfo(factionIndex)
		end
		factionIndex = factionIndex + 1
	until factionIndex > 200
end


local gender = UnitSex("player")

FuBar_FactionsFu = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0", "AceDB-2.0", "AceHook-2.1", "FuBarPlugin-2.0")
local FuBar_FactionsFu = FuBar_FactionsFu
FuBar_FactionsFu.revision = tonumber(string.sub("$Revision: 81 $", 12, -3)) or 1

FuBar_FactionsFu.hasIcon = "Interface\\Icons\\Spell_Holy_SealOfSalvation"
FuBar_FactionsFu.canHideText = true
FuBar_FactionsFu.clickableTooltip = true
FuBar_FactionsFu:RegisterDB("FuBar_FactionsFuDB")
FuBar_FactionsFu:RegisterDefaults("profile", {
	text = {
		show_name = true,
		show_standing = true,
		show_progress = true,
		show_percent = true,
	},
	color = {
		name = "ATWAR",
		standing = "DEFAULT",
		reputation = "INC",
	},
	other = {
		autozone = true,
		autogain = false,
	},
	AutoZoneFaction = {
	},
})
FuBar_FactionsFu:RegisterDefaults("char", {
	collapsed = {},
})

FuBar_FactionsFu.SessionChangesBase = {}

function FuBar_FactionsFu:OnInitialize()
	self.factions = {}
end

function FuBar_FactionsFu:OnEnable()
	self:RegisterBucketEvent("UPDATE_FACTION", 1)

	self:RegisterEvent("ZONE_CHANGED", "ZoneUpdate")
	self:RegisterEvent("ZONE_CHANGED_INDOORS", "ZoneUpdate")
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA", "ZoneUpdate")
	self:RegisterEvent("MINIMAP_ZONE_CHANGED", "ZoneUpdate")
	self:RegisterEvent("PLAYER_ENTERING_WORLD", "ZoneUpdate")

--	self:RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE")

	self:SecureHook("SetWatchedFactionIndex", "Hook_SetWatchedFactionIndex")
	self:SecureHook("CollapseFactionHeader", "Hook_CollapseFactionHeader")
	self:SecureHook("ExpandFactionHeader", "Hook_ExpandFactionHeader")

	self:Update()
end

-- function FuBar_FactionsFu:OnDisable()
-- end

local tablecache = {}
local function recyclefactiontable(t)
	while #t > 0 do
		table_insert(tablecache, table_remove(t))
	end
	return t
end
local function getfactiontable(...)
	local t
	if #tablecache > 0 then
		t = table_remove(tablecache)
	else
		t = {}
	end
	for i = 1, select('#', ...), 2 do
		t[select(i, ...)] = select(i + 1, ...)
	end
	return t
end

local collapsids = {}
function FuBar_FactionsFu:OnDataUpdate()
	local factions = recyclefactiontable(self.factions)

	local header = UNKNOWN
	
	local numFactions = GetNumFactions()
	local factionIndex, factionName, factionCheck, factionStanding, factionBar, factionHeader, color, tooltipStanding
	local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild
	local atWarIndicator, rightBarTexture

	self.watched = nil
	self.watchedid = 0

	local collapsedheaders = self.db.char.collapsed

	for i=1, numFactions do
		name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetFactionInfo(i)
		if ( isHeader ) then
			header = name
			table_insert(self.factions, getfactiontable("name", header, "isHeader", true, "isCollapsed", isCollapsed, "isChild", isChild))
			if collapsedheaders[header] and not isCollapsed then
--				self:Print("Loop 1:", i, name, isHeader, isCollapsed)
				table_insert(collapsids, i)
			end
		else
			if header ~= UNKNOWN then
				-- Normalize values
				table_insert(factions, getfactiontable("name", name, "isHeader", false, "standing", standingID, "repIs", barValue - barMin, "repMax", barMax - barMin, "repAbs", barValue, "atWarWith", atWarWith, "canToggleAtWar", canToggleAtWar, "isWatched", isWatched, "hasRep", hasRep, "isChild", isChild))
				if not self.SessionChangesBase[name] then self.SessionChangesBase[name] = barValue end
				if isWatched then
					self.watched = name
					self.watchedid = i
				end
			end
		end
	end
	self.factions = factions
	table_sort(collapsids)
	for i = #collapsids, 1, -1 do
		local id = collapsids[i]
		name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetFactionInfo(id)
--		self:Print("Loop 2:", id, name, isHeader, isCollapsed)
		if isHeader and not isCollapsed then
			CollapseFactionHeader(id)
		end
		collapsids[i] = nil
	end
end

function FuBar_FactionsFu:OnTextUpdate()
	local name, description, standing, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetWatchedFactionFullInfo()
	if name then
		local repIs = barValue - barMin
		local repMax = barMax - barMin
		local text = ""
		if self.db.profile.text.show_name then
			text = select(4, self:GetColor_ATWAR(atWarWith, canToggleAtWar, self.db.profile.color.name))..name.."|r"
			if self.db.profile.text.show_standing or self.db.profile.text.show_progress or self.db.profile.text.show_percent then
				text = text.."|cffffffff: |r"
			end
		end
		local standinghex = select(4, self:GetColor_standing(standing, self.db.profile.color.standing))
		local rephex = select(4, self:GetColor_standing(standing, self.db.profile.color.reputation))
		if self.db.profile.text.show_standing and self.db.profile.text.show_progress and self.db.profile.text.show_percent then
			text = text..("%s%s|r|cffffffff - |r%s%d/%d (%.1f%%)|r"):format(standinghex, GetText("FACTION_STANDING_LABEL"..standing, gender), rephex, repIs, repMax, repIs / repMax * 100)
		elseif self.db.profile.text.show_standing and self.db.profile.text.show_progress and not self.db.profile.text.show_percent then
			text = text..("%s%s|r|cffffffff - |r%s%d/%d|r"):format(standinghex, GetText("FACTION_STANDING_LABEL"..standing, gender), rephex, repIs, repMax)
		elseif self.db.profile.text.show_standing and not self.db.profile.text.show_progress and self.db.profile.text.show_percent then
			text = text..("%s%s|r|cffffffff - |r%s%.1f%%|r"):format(standinghex, GetText("FACTION_STANDING_LABEL"..standing, gender), rephex, repIs / repMax * 100)
		elseif self.db.profile.text.show_standing and not self.db.profile.text.show_progress and not self.db.profile.text.show_percent then
			text = text..("%s%s|r"):format(standinghex, GetText("FACTION_STANDING_LABEL"..standing, gender))
		elseif not self.db.profile.text.show_standing and self.db.profile.text.show_progress and self.db.profile.text.show_percent then
			text = text..("%s%d/%d (%.1f%%)|r"):format(rephex, repIs, repMax, repIs / repMax * 100)
		elseif not self.db.profile.text.show_standing and self.db.profile.text.show_progress and not self.db.profile.text.show_percent then
			text = text..("%s%d/%d|r"):format(rephex, repIs, repMax)
		elseif not self.db.profile.text.show_standing and not self.db.profile.text.show_progress and self.db.profile.text.show_percent then
			text = text..("%s%.1f%%|r"):format(rephex, repIs / repMax * 100)
		end
		self:SetText(text)
	else
		self:SetText("|cffffffffFactions|cff00ff00Fu|r")
	end
end

function FuBar_FactionsFu:OnTooltipUpdate()
	local DBprofile = self.db.profile

	local parentcat, childcat
	local childlevel = nil
	local curZone = GetRealZoneText()
	local supercat = tablet:AddCategory(
		'columns', 5
	)
	local header = UNKNOWN
	parentcat = supercat
	for i, factiondata in ipairs(self.factions) do
		if factiondata.isChild ~= childlevel then
			if factiondata.isChild then
				parentcat = childcat
			else
				childcat = parentcat
				parentcat = supercat
			end
			childlevel = factiondata.isChild
		end
		if factiondata.isHeader then
			header = factiondata.name
			childcat = parentcat:AddCategory(
				'indentation', factiondata.isChild and 15 or 0,
				'child_indentation', factiondata.isChild and 15 or 0,
				'text', header,
				'columns', 5,
				'hideBlankLine', true,
				'showWithoutChildren', true,
				'hasCheck', true,
				'checked', true,
				'checkIcon', factiondata.isCollapsed and "Interface\\Buttons\\UI-PlusButton-Up" or "Interface\\Buttons\\UI-MinusButton-Up",
				'func', 'OnClickTooltip',
				'arg1', self,
				'arg2', i
			)
		else
			local faction_name = factiondata.name
			local warcolorR, warcolorG, warcolorB = self:GetColor_ATWAR(factiondata.atWarWith, factiondata.canToggleAtWar, DBprofile.color.name)
			local standingcolorR, standingcolorG, standingcolorB = self:GetColor_standing(factiondata.standing, DBprofile.color.standing)
			local repcolorR, repcolorG, repcolorB = self:GetColor_standing(factiondata.standing, DBprofile.color.reputation)
			local sessionChange = self.SessionChangesBase[faction_name] and factiondata.repAbs - self.SessionChangesBase[faction_name] or 0
			childcat:AddLine(
				'text', faction_name,
				'textR', warcolorR,
				'textG', warcolorG,
				'textB', warcolorB,
				'text2', GetText("FACTION_STANDING_LABEL"..factiondata.standing, gender),
				'text2R', standingcolorR,
				'text2G', standingcolorG,
				'text2B', standingcolorB,
				'text3', ("%5d / %5d"):format(factiondata.repIs, factiondata.repMax),
				'text3R', repcolorR,
				'text3G', repcolorG,
				'text3B', repcolorB,
				'text4', ("%.1f%%"):format(factiondata.repIs / factiondata.repMax * 100),
				'text4R', repcolorR,
				'text4G', repcolorG,
				'text4B', repcolorB,
				'justify4', "RIGHT",
				'text5',  sessionChange > 0 and "+"..sessionChange or sessionChange < 0 and sessionChange or "-",
				'text5R', sessionChange > 0 and 0 or 1,
				'text5G', sessionChange < 0 and 0 or 1,
				'text5B', sessionChange ~= 0 and 0 or 1,
				'justify5', "RIGHT",
				'hasCheck', true,
				'checked', factiondata.isWatched or faction_name == DBprofile.AutoZoneFaction[curZone] or faction_name == self.db.char.lastFaction,
--				'checkIcon', (faction_name == self.db.profile.AutoZoneFaction[curZone] and "Spell_Holy_MagicalSentry") or "Interface\\Buttons\\UI-RadioButton",
				'func', 'OnClickTooltip',
				'arg1', self,
				'arg2', i,
				(faction_name == DBprofile.AutoZoneFaction[curZone] and 'checkIcon') or nil, (faction_name == DBprofile.AutoZoneFaction[curZone] and "Interface\\Icons\\Ability_Hunter_SniperShot")
			)
		end
	end
	tablet:SetHint(L["TOOLTIP_HINT"])
end

function FuBar_FactionsFu:OnClick()
	if IsShiftKeyDown() then
		local activeWindow = ChatEdit_GetActiveWindow()
		if activeWindow then
			local name, standing, barMin, barMax, barValue = GetWatchedFactionInfo()
			local repIs = barValue - barMin
			local repMax = barMax - barMin
			activeWindow:Insert(("%s: %s - %d/%d (%.1f%%)"):format(name, GetText("FACTION_STANDING_LABEL"..standing, gender), repIs, repMax, repIs / repMax * 100))
		end
	else
		ToggleCharacter("ReputationFrame")
	end
end

function FuBar_FactionsFu:UPDATE_FACTION()
	self:Update()
end

function FuBar_FactionsFu:OnClickTooltip(id)
	local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetFactionInfo(id)
	if IsControlKeyDown() then
		if isHeader then
			if isCollapsed then
				ExpandFactionHeader(id)
			else
				CollapseFactionHeader(id)
			end
		else
			if IsFactionInactive(id) then
				SetFactionActive(id)
			else
				SetFactionInactive(id)
			end
		end
	elseif IsShiftKeyDown() then
		local activeWindow = ChatEdit_GetActiveWindow()
		if activeWindow then
			local repIs = barValue - barMin
			local repMax = barMax - barMin
			activeWindow:Insert(("%s: %s - %d/%d (%.1f%%)"):format(name, GetText("FACTION_STANDING_LABEL"..standingID, gender), repIs, repMax, repIs / repMax * 100))
		end
		return
	elseif IsAltKeyDown() then
		local curZone = GetRealZoneText()
		if self.db.profile.AutoZoneFaction[curZone] and self.db.profile.AutoZoneFaction[curZone] == name then
			self.db.profile.AutoZoneFaction[curZone] = nil
		else
			self.db.profile.AutoZoneFaction[curZone] = name
		end
		self:SetAutoFaction(curZone)
	elseif not isHeader or hasRep then
		if isWatched then
			PlaySound("igMainMenuOptionCheckBoxOff")
			SetWatchedFactionIndex(0)
		else
			PlaySound("igMainMenuOptionCheckBoxOn")
			SetWatchedFactionIndex(id)
		end
	end
	self:Update()
end

function FuBar_FactionsFu:GetColor_ATWAR(atwar, canwar, type)
	if type == "ATWAR" then
		if atwar then
			return 1, 0, 0, "|cffff0000"
		elseif canwar then
			return 1, 1, 0, "|cffffff00"
		else
			return 0, 1, 0, "|cff00ff00"
		end
	end
	return 1, 1, 1, "|cffffffff"
end

local INC_COLORS = {
	[1] = {r = 0.55, g = 0, b = 0},			-- hated
	[2] = {r = 1, g = 0, b = 0},			-- hostile
	[3] = {r = 1, g = 0.55, b = 0},			-- unfriendly
	[4] = {r = 0.75, g = 0.75, b = 0.75},	-- neutral
	[5] = {r = 1, g = 1, b = 1},			-- friendly
	[6] = {r = 0, g = 1, b = 0},			-- honored
	[7] = {r = 0.25, g = 0.4, b = 0.9},		-- reverted
	[8] = {r = 0.6, g = 0.2, b = 0.8},		-- exalted
}

function FuBar_FactionsFu:GetColor_standing(standing, type)
	if type == "DEFAULT" then
		local color = FACTION_BAR_COLORS[standing]
		return color.r, color.g, color.b, ("|cff%02x%02x%02x"):format(color.r * 255, color.g * 255, color.b * 255)
	end
	if type == "INC" then
		local color = INC_COLORS[standing]
		return color.r, color.g, color.b, ("|cff%02x%02x%02x"):format(color.r * 255, color.g * 255, color.b * 255)
	end
	return 1, 1, 1, "|cffffff00"
end

function FuBar_FactionsFu:ZoneUpdate()
	local curZone = GetRealZoneText()
	if self.lastZone ~= curZone then
		self:SetAutoFaction(curZone)
		self.lastZone = curZone
	end
end

function FuBar_FactionsFu:SetAutoFaction(zone)
	if not self.db.profile.other.autozone then return end
	-- is there a auto-faction set for the current zone?
	if self.db.profile.AutoZoneFaction[zone] then
		-- if lastFaction is set, last zone had autofaction, too
		-- if not we have to store the current watched faction
		if self.db.char.lastFaction == nil then
			self.db.char.lastFaction = self.watched or false
		end
		self.SettingAutoFaction = true
		self:SetWatchedFactionName(self.db.profile.AutoZoneFaction[zone])
	-- no auto-faction set so restore last faction if set
	elseif self.db.char.lastFaction ~= nil then
		self.SettingAutoFaction = true
		self:SetWatchedFactionName(self.db.char.lastFaction)
		self.db.char.lastFaction = nil
	end
end

function FuBar_FactionsFu:SetWatchedFactionName(factionname)
--	self:Print("SetWatchedFactionName(", factionname, ") called...")
	if factionname == false then
		SetWatchedFactionIndex(0)
		return
	end
	local factionIndex = 1
	local lastFactionName
	repeat
		local name = GetFactionInfo(factionIndex)
		if name == lastFactionName then break end
		lastFactionName  = name
		if name == factionname then
			SetWatchedFactionIndex(factionIndex)
			return
		end
		factionIndex = factionIndex + 1
	until factionIndex > 200
end

function FuBar_FactionsFu:Hook_SetWatchedFactionIndex(id)
--	self:Print("SetWatchedFactionIndex(", id, ") called...")
	if not self.SettingAutoFaction then
		self.db.char.lastFaction = nil
		if not id or id <= 0 then
			local curZone = GetRealZoneText()
			if self.db.profile.AutoZoneFaction[cuZone] then
				self:SetAutoFaction(curZone)
			end
		end
	end
	self.SettingAutoFaction = nil
end

function FuBar_FactionsFu:Hook_CollapseFactionHeader(id)
	local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetFactionInfo(id)
--	self:Print("CollapseFactionHeader:", id, name, isHeader, isCollapsed)
	if not (name and isHeader) then return end
	self.db.char.collapsed[name] = true
end

function FuBar_FactionsFu:Hook_ExpandFactionHeader(id)
	local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild = GetFactionInfo(id)
--	self:Print("ExpandFactionHeader:", id, name, isHeader, isCollapsed)
	if not name then return end
	self.db.char.collapsed[name] = nil
end

--~ function FuBar_FactionsFu:CHAT_MSG_COMBAT_FACTION_CHANGE()
--~ 	local faction, change
--~ --	self:Print("FACTION_STANDING_CHANGED:", deformat(arg1, FACTION_STANDING_CHANGED))
--~ --	self:Print("FACTION_STANDING_INCREASED", deformat(arg1, FACTION_STANDING_INCREASED))
--~ --	self:Print("FACTION_STANDING_DECREASED", deformat(arg1, FACTION_STANDING_DECREASED))
--~ 	faction, change = deformat(arg1, FACTION_STANDING_INCREASED)
--~ 	if faction and change then
--~ 		self.SessionChanges[faction] = (self.SessionChanges[faction] or 0) + change
--~ 	else
--~ 		faction, change = deformat(arg1, FACTION_STANDING_DECREASED)
--~ 		if faction and change then
--~ 			self.SessionChanges[faction] = (self.SessionChanges[faction] or 0) - change
--~ 		end
--~ 	end
--~ 	self:UpdateTooltip()
--~ end
