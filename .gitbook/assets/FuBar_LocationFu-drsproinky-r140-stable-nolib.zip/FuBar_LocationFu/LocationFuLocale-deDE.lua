local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_LocationFu")

L:AddTranslations("deDE", function() return {
	["Open world map"] = "Weltkarte öffnen",
	["Open Atlas"] = "Atlas öffnen",
	["Show coordinates"] = "Koordinaten anzeigen",
	["Toggle the coordinates in the text of this plugin"] = "Koordinaten in der Anzeige dieses Plugins ein-/ausschalten",
	["Show subzone name"] = "Namen der Gebietsteile anzeigen",
	["Show zone name"] = "Gebietsnamen anzeigen",
	["Toggle the zone name in the text of this plugin"] = "Gebietsnamen in der Anzeige dieses Plugins ein-/ausschalten",
	["Show level range"] = "Stufenbereich anzeigen",
	["Show minimap bar"] = "Titelleiste der Minikarte anzeigen",
	["Show the bar above the minimap that tells the location and allows you to close minimap"] = "Zeigt die Titelleiste der Minikarte an, mit der die Minikarte ein- und ausgeschaltet werden kann",
	["Show recommended zones"] = "Empfohlene Gebiete anzeigen",
	["Show your recommended zones in the tooltip"] = "Zeigt die für Euch empfohlenen Gebiete im Tooltip",
	["Zone:"] = "Gebiet:",
	["Subzone:"] = "Gebietsteil:",
	["Fishing:"] = "Angeln:",
	["Arena"] = "Arena",
	["Friendly"] = "Freundlich",
	["Contested"] = "Umkämpft",
	["Hostile"] = "Feindselig",
	["Sanctuary"] = "Sicher",
	["Status:"] = "Status:",
	["Coordinates:"] = "Koordinaten:",
	["Level range:"] = "Stufenbereich:",
	["Instances"] = "Instanzen",
	["Recommended zones"] = "Empfohlene Gebiete",
	["Recommended instances"] = "Empfohlene Instanzen",
	["Continent:"] = "Kontinent:",
	
	["    Walk path from %s to %s:"] = "    Laufweg von %s zu %s:",
	["    No path found"] = "    Keinen Weg gefunden",
	
	["%d-man"] = "%d Spieler",
	
	["Atlas-hint"] = "Linksklick öffnet Atlas",
	["Standard-hint"] = "Linksklick öffnet die Karte",
	["Shift-hint"] = "Shift-Linksklick fügt Position in die Chat-Eingabezeile ein",
	["Ctrl-hint"] = "Strg-Linksklick öffnet die Karte",
	["Ctrl-Atlas-hint"] = "Strg-Linksklick öffnet Atlas",
	
	["AceConsole-options"] = {"/locfu", "/locationfu"},
} end)
