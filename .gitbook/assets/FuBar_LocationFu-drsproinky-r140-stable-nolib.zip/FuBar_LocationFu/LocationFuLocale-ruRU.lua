﻿local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_LocationFu")

L:AddTranslations("ruRU", function() return {
	["Open world map"] = "Открыть карту мира",
	["Open Atlas"] = "Открыть Атлас",
	["Show coordinates"] = "Показывать координаты",
	["Toggle the coordinates in the text of this plugin"] = "Отображение координат на панели FuBar",
	["Show subzone name"] = "Показывать имя подзоны",
	["Show zone name"] = "Показывать имя зоны",
	["Toggle the zone name in the text of this plugin"] = "Отображение названия зоны на панели FuBar",
	["Show level range"] = "Показывать уровни зоны",
	["Show minimap bar"] = "Показывать зону над миникартой",
	["Show the bar above the minimap that tells the location and allows you to close minimap"] = "Отображение полосы над миникартой, показывающей текущую зоны и кнопку закрытия миникарты",
	["Show recommended zones"] = "Показывать рекомендованные зоны",
	["Show your recommended zones in the tooltip"] = "Отображение рекомендованных зоны во всплывающей подсказке",
	["Zone:"] = "Зона: ",
	["Subzone:"] = "Подзона: ",
	["Fishing:"] = "Рыбная ловля: ",
	["Arena"] = "Арена",
	["Friendly"] = "Дружественная",
	["Contested"] = "Оспариваемая",
	["Hostile"] = "Вражеская",
	["Status:"] = "Статус: ",
	["Sanctuary"] = "Святилище",
	["Coordinates:"] = "Координаты: ",
	["Level range:"] = "Уровень: ",
	["Instances"] = "Подземелья",
	["Recommended zones"] = "Рекомендованные зоны",
	["Recommended instances"] = "Рекомендованные подземелья",
	["Continent:"] = "Континент",
	
	["    Walk path from %s to %s:"] = "    Пеший путь из %s в %s:",
	["    No path found"] = "    Путь не найден",
	
	["%d-man"] = "%d-ппл", -- as in a 40-man raid
	
	["Atlas-hint"] = "|cffeda55fЛевый клик|r - открыть Атлас",
	["Standard-hint"] = "|cffeda55fЛевый клик|r - открыть карту",
	["Shift-hint"] = "|cffeda55fShift+Левый клик|r - вставить текущую позицию в чат",
	["Ctrl-hint"] = "|cffeda55fCtrl+Левый клик|r - октрыть карту",
	["Ctrl-Atlas-hint"] = "|cffeda55fCtrl+Левый клик|r - открыть Аталас",
	
	["AceConsole-options"] = {"/locfu", "/locationfu"},
	[". "] = ". ",
	["."] = ".",
} end)
