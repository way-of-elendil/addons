local function AddProfessionIconsToTooltip(tooltip)
    local name, link = tooltip:GetItem()
    if not link then return end

    local itemId = tonumber(string.match(link, "item:(%d+):"))
    if not itemId then return end

    -- Vérifiez si l'ID de l'objet est dans ITEM_PROF_FLAGS
    local itemProfFlags = ProfessionPointerConstants.ITEM_PROF_FLAGS[itemId]
    if itemProfFlags then
	
        local iconSize = ProfessionPointerConstants.ICON_SIZE
        local icons = "" -- Initialise une chaîne pour stocker toutes les icônes

        -- Si l'objet est utiliser dans la profession Forgeron
        if ProfessionPointerDB.BS and bit.band(itemProfFlags, ProfessionPointerConstants.BS) ~= 0 then
            -- Ajouter l'icône de la profession Forgeron à l'infobulle
            icons = icons .. "|TInterface\\Icons\\Trade_BlackSmithing:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Travail du cuir
        if ProfessionPointerDB.LW and bit.band(itemProfFlags, ProfessionPointerConstants.LW) ~= 0 then
            -- Ajouter l'icône de la profession Travail du cuir à l'infobulle
            icons = icons .. "|TInterface\\Icons\\Inv_misc_armorkit_17:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Alchimiste
        if ProfessionPointerDB.ALC and bit.band(itemProfFlags, ProfessionPointerConstants.ALC) ~= 0 then
            -- Ajouter l'icône de la profession Alchimiste à l'infobulle
            icons = icons .. "|TInterface\\Icons\\Trade_alchemy:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Cuisine
        if ProfessionPointerDB.COOK and bit.band(itemProfFlags, ProfessionPointerConstants.COOK) ~= 0 then
            -- Ajouter l'icône de la profession Cuisine à l'infobulle
            icons = icons .. "|TInterface\\Icons\\Inv_misc_food_15:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Premier Secours
        if ProfessionPointerDB.FAID and bit.band(itemProfFlags, ProfessionPointerConstants.FAID) ~= 0 then
            -- Ajouter l'icône de la profession Premier Secours à l'infobulle
            icons = icons .. "|TInterface\\Icons\\Spell_Holy_SealOfSacrifice:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Couture
        if ProfessionPointerDB.TAIL and bit.band(itemProfFlags, ProfessionPointerConstants.TAIL) ~= 0 then
            -- Ajouter l'icône de la profession Couture
            icons = icons .. "|TInterface\\Icons\\Trade_tailoring:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Ingénieur
        if ProfessionPointerDB.ENG and bit.band(itemProfFlags, ProfessionPointerConstants.ENG) ~= 0 then
            -- Ajouter l'icône de la profession Ingénieur
            icons = icons .. "|TInterface\\Icons\\Trade_engineering:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Enchanteur
        if ProfessionPointerDB.ENC and bit.band(itemProfFlags, ProfessionPointerConstants.ENC) ~= 0 then
            -- Ajouter l'icône de la profession Enchanteur
            icons = icons .. "|TInterface\\Icons\\Trade_engraving:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Joaillerie
        if ProfessionPointerDB.JC and bit.band(itemProfFlags, ProfessionPointerConstants.JC) ~= 0 then
            -- Ajouter l'icône de la profession Joaillerie
            icons = icons .. "|TInterface\\Icons\\Inv_misc_gem_01:"..iconSize..":"..iconSize.."|t "
        end
        -- Si l'objet est utiliser dans la profession Calligraphie
        if ProfessionPointerDB.INS and bit.band(itemProfFlags, ProfessionPointerConstants.INS) ~= 0 then
            -- Ajouter l'icône de la profession Calligraphie
            icons = icons .. "|TInterface\\Icons\\Inv_inscription_tradeskill01:"..iconSize..":"..iconSize.."|t "
        end

        -- Si des icônes ont été ajoutées, ajoutez-les à l'infobulle
        if icons ~= "" then
            tooltip:AddLine("\n" .. icons)
        end
    end
end

-- Accrocher le script à l'infobulle du jeu
GameTooltip:HookScript("OnTooltipSetItem", function(tooltip)
    AddProfessionIconsToTooltip(tooltip)
end)