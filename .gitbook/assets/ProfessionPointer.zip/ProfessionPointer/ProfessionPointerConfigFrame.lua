if not ProfessionPointerDB then
    ProfessionPointerDB = {BS = true, FAID = true, JC = true, IconSize = 50}
end

-- Crée un panneau pour l'interface utilisateur
local panel = CreateFrame("Frame", "ProfessionPointerConfigPanel");
panel.name = "ProfessionPointer";

-- Ajoute le panneau à l'interface utilisateur
InterfaceOptions_AddCategory(panel);

-- Ajoute un titre au panneau
panel.title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
panel.title:SetPoint("TOPLEFT", 20, -10);
panel.title:SetText("");

-- Crée une case à cocher pour le métier Forgeron
local bsCheckbox = CreateFrame("CheckButton", "ProfessionPointerBSCheckbox", panel, "OptionsCheckButtonTemplate");
bsCheckbox:SetPoint("TOPLEFT", panel.title, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
bsCheckbox.Text = bsCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
bsCheckbox.Text:SetPoint("LEFT", bsCheckbox, "RIGHT", 0, 0)
bsCheckbox.Text:SetText("Afficher l'icône Forgeron")
bsCheckbox:SetChecked(ProfessionPointerDB.BS)
bsCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.BS = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Travail du cuir
local lwCheckbox = CreateFrame("CheckButton", "ProfessionPointerLWCheckbox", panel, "OptionsCheckButtonTemplate");
lwCheckbox:SetPoint("TOPLEFT", bsCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
lwCheckbox.Text = lwCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
lwCheckbox.Text:SetPoint("LEFT", lwCheckbox, "RIGHT", 0, 0)
lwCheckbox.Text:SetText("Afficher l'icône Travail du cuir")
lwCheckbox:SetChecked(ProfessionPointerDB.LW)
lwCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.LW = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Alchimiste
local alcCheckbox = CreateFrame("CheckButton", "ProfessionPointerALCCheckbox", panel, "OptionsCheckButtonTemplate");
alcCheckbox:SetPoint("TOPLEFT", lwCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
alcCheckbox.Text = alcCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
alcCheckbox.Text:SetPoint("LEFT", alcCheckbox, "RIGHT", 0, 0)
alcCheckbox.Text:SetText("Afficher l'icône Alchimiste")
alcCheckbox:SetChecked(ProfessionPointerDB.ALC)
alcCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.ALC = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Cuisine
local cookCheckbox = CreateFrame("CheckButton", "ProfessionPointerCOOKCheckbox", panel, "OptionsCheckButtonTemplate");
cookCheckbox:SetPoint("TOPLEFT", alcCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
cookCheckbox.Text = cookCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
cookCheckbox.Text:SetPoint("LEFT", cookCheckbox, "RIGHT", 0, 0)
cookCheckbox.Text:SetText("Afficher l'icône Cuisine")
cookCheckbox:SetChecked(ProfessionPointerDB.COOK)
cookCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.COOK = self:GetChecked()
end)

-- Crée une case à cocher pour le métier FAID
local faidCheckbox = CreateFrame("CheckButton", "ProfessionPointerFAIDCheckbox", panel, "OptionsCheckButtonTemplate");
faidCheckbox:SetPoint("TOPLEFT", cookCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
faidCheckbox.Text = faidCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
faidCheckbox.Text:SetPoint("LEFT", faidCheckbox, "RIGHT", 0, 0)
faidCheckbox.Text:SetText("Afficher l'icône Premiers Secours")
faidCheckbox:SetChecked(ProfessionPointerDB.FAID)
faidCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.FAID = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Couture
local tailCheckbox = CreateFrame("CheckButton", "ProfessionPointerTAILCheckbox", panel, "OptionsCheckButtonTemplate");
tailCheckbox:SetPoint("TOPLEFT", faidCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
tailCheckbox.Text = tailCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
tailCheckbox.Text:SetPoint("LEFT", tailCheckbox, "RIGHT", 0, 0)
tailCheckbox.Text:SetText("Afficher l'icône Couture")
tailCheckbox:SetChecked(ProfessionPointerDB.TAIL)
tailCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.TAIL = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Ingénieur
local engCheckbox = CreateFrame("CheckButton", "ProfessionPointerENGCheckbox", panel, "OptionsCheckButtonTemplate");
engCheckbox:SetPoint("TOPLEFT", tailCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
engCheckbox.Text = engCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
engCheckbox.Text:SetPoint("LEFT", engCheckbox, "RIGHT", 0, 0)
engCheckbox.Text:SetText("Afficher l'icône Ingénieur")
engCheckbox:SetChecked(ProfessionPointerDB.ENG)
engCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.ENG = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Enchanteur
local encCheckbox = CreateFrame("CheckButton", "ProfessionPointerENCCheckbox", panel, "OptionsCheckButtonTemplate");
encCheckbox:SetPoint("TOPLEFT", engCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
encCheckbox.Text = encCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
encCheckbox.Text:SetPoint("LEFT", encCheckbox, "RIGHT", 0, 0)
encCheckbox.Text:SetText("Afficher l'icône Echanteur")
encCheckbox:SetChecked(ProfessionPointerDB.ENC)
encCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.ENC = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Joaillerie
local jcCheckbox = CreateFrame("CheckButton", "ProfessionPointerJCCheckbox", panel, "OptionsCheckButtonTemplate");
jcCheckbox:SetPoint("TOPLEFT", encCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
jcCheckbox.Text = jcCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
jcCheckbox.Text:SetPoint("LEFT", jcCheckbox, "RIGHT", 0, 0)
jcCheckbox.Text:SetText("Afficher l'icône Joaillerie")
jcCheckbox:SetChecked(ProfessionPointerDB.JC)
jcCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.JC = self:GetChecked()
end)

-- Crée une case à cocher pour le métier Calligraphie
local insCheckbox = CreateFrame("CheckButton", "ProfessionPointerINSCheckbox", panel, "OptionsCheckButtonTemplate");
insCheckbox:SetPoint("TOPLEFT", jcCheckbox, "BOTTOMLEFT", 0, -10);
-- Crée une chaîne de caractères pour le texte de la case à cocher
insCheckbox.Text = insCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
insCheckbox.Text:SetPoint("LEFT", insCheckbox, "RIGHT", 0, 0)
insCheckbox.Text:SetText("Afficher l'icône Calligraphie")
insCheckbox:SetChecked(ProfessionPointerDB.INS)
insCheckbox:SetScript("OnClick", function(self)
    ProfessionPointerDB.INS = self:GetChecked()
end)

-- Crée un curseur pour la taille des icônes
local iconSizeSlider = CreateFrame("Slider", "ProfessionPointerIconSizeSlider", panel, "OptionsSliderTemplate")
iconSizeSlider:SetPoint("CENTER", faidCheckbox, "CENTER", 170, -222)
iconSizeSlider:SetMinMaxValues(20, 80) -- Définit les valeurs minimale et maximale du curseur
iconSizeSlider:SetValueStep(1) -- Définit l'incrément de la valeur du curseur
iconSizeSlider:SetValue(ProfessionPointerDB.IconSize or 50)

-- Crée une chaîne de caractères pour le texte au-dessus du curseur
iconSizeSlider.TopText = iconSizeSlider:CreateFontString(nil, "OVERLAY", "GameFontNormal")
iconSizeSlider.TopText:SetPoint("BOTTOM", iconSizeSlider, "TOP", 0, 3)
iconSizeSlider.TopText:SetText("Taille des icônes de profession")

-- Crée une chaîne de caractères pour le texte du curseur
iconSizeSlider.Text = iconSizeSlider:CreateFontString(nil, "OVERLAY", "GameFontNormal")
iconSizeSlider.Text:SetPoint("LEFT", iconSizeSlider, "RIGHT", 10, 0)

-- Crée une chaîne de caractères pour la valeur du curseur
iconSizeSlider.ValueText = iconSizeSlider:CreateFontString(nil, "OVERLAY", "GameFontNormal")
iconSizeSlider.ValueText:SetPoint("TOP", iconSizeSlider, "BOTTOM", 0, -3)

-- Met à jour le texte de la valeur du curseur lorsque la valeur du curseur change
iconSizeSlider:SetScript("OnValueChanged", function(self, value)
    self.ValueText:SetText(string.format("%.0f", value))
    -- Mettre à jour la taille de l'icône
    ProfessionPointerConstants.ICON_SIZE = value
    -- Sauvegarder la taille de l'icône
    ProfessionPointerDB.IconSize = value
end)

-- Initialise le texte de la valeur du curseur
iconSizeSlider.ValueText:SetText(string.format("%.0f", iconSizeSlider:GetValue()))

-- Lorsque le jeu démarre
local function OnAddonLoaded()
    -- Récupérer la taille de l'icône sauvegardée
    local savedIconSize = ProfessionPointerDB.IconSize
    if savedIconSize then
        -- Mettre à jour la taille de l'icône et la position du curseur
        ProfessionPointerConstants.ICON_SIZE = tonumber(savedIconSize)
        iconSizeSlider:SetValue(ProfessionPointerConstants.ICON_SIZE)
    end

    -- Récupérer l'état enregistré des cases à cocher
    local savedBS = ProfessionPointerDB.BS
        bsCheckbox:SetChecked(savedBS)

    local savedLW = ProfessionPointerDB.LW
        lwCheckbox:SetChecked(savedLW)

    local savedALC = ProfessionPointerDB.ALC
        alcCheckbox:SetChecked(savedALC)

    local savedCOOK = ProfessionPointerDB.COOK
        cookCheckbox:SetChecked(savedCOOK)

    local savedFAID = ProfessionPointerDB.FAID
        faidCheckbox:SetChecked(savedFAID)

    local savedTAIL = ProfessionPointerDB.TAIL
        tailCheckbox:SetChecked(savedTAIL)

    local savedENG = ProfessionPointerDB.ENG
        engCheckbox:SetChecked(savedENG)

    local savedENC = ProfessionPointerDB.ENC
        encCheckbox:SetChecked(savedENC)

    local savedJC = ProfessionPointerDB.JC
        jcCheckbox:SetChecked(savedJC)

    local savedINS = ProfessionPointerDB.INS
        insCheckbox:SetChecked(savedINS)
    end

-- Accrocher le script à l'événement ADDON_LOADED
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "ProfessionPointer" then
        -- L'addon a été chargé, initialiser la taille de l'icône
        OnAddonLoaded()
    end
end)