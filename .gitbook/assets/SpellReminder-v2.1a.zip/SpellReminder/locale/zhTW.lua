local L = AceLibrary("AceLocale-2.2"):new("SpellReminder")
L:RegisterTranslations("zhTW", function() return {
	-- core
	["None"] = "無",
	["Expiring Only"] = "僅監控即將消失的",
	["Expired Only"] = "僅監控已經消失的",
	["Both"] = "兩者都監控",
	
	[" Totem"] = "圖騰", --  there's no space in Chinese
	[" Weapon"] = "武器", -- there's no space in Chinese
	
	["Detected new spell! (%s)"] = "偵測到新技能! (%s)", -- spell name

	["Normal"] = "普通",
	["Emphasis"] = "重要",
	
	["%s has had its custom group reset."] = "%s 已經自訂的群組.", -- spell name
	["Filter for '%s' has been reset."] = "'%s' 過濾器已重置", -- filter name
	["You should reload your UI after deleting a bar group."] = "刪除一個群組後你必須重新讀取你的插件",
	
	["%s over in %d seconds!"] = "%s 將在 %d 秒後消失!", -- bar name ,  seconds
	["%s has EXPIRED!"] = "%s 已消失", -- bar name

	["Filter Priorities"] = "過濾器優先權",
	["Set priorities for the filters."] = "設定過濾器的優先權",
	["Increase the priority of this filter."] = "增加過濾器的優先權",
	["Highest Priority"] = "最高優先權",
	["Lowest Priority"] = "最低優先權",
	
	-- options
	["Click a spell to stop tracking."] = "點擊技能以停止監控.",
	["Options for SpellReminder."] = "SpellReminder選項",
	["Spell Setup"] = "技能設定",
	["Setup spell reminders."] = "設定技能過期提醒",
	["Inactive"] = "閒置",
	["Inactive Spells"] = "閒置的技能",
	["Disable Detection"] = "禁用偵測",
	["Disables the detection of new spells."] = "禁用偵測新技能",
	["Default Bar Color"] = "預設計時條顏色",
	["Set the default color of the reminder bars."] = "設定預設計時條顏色",
	["Clear All Spells"] = "清除所有技能",
	["Will force SpellReminder to forget all options for ALL spells, including detected spells and pet spells."] = "強制清除所有技能到期提醒的設定",
	["Clear Inactive Spells"] = "清除閒置的技能",
	["Will force SpellReminder to forget all options for inactive spells."] = "强制清除所有閒置的技能",
	["Timer Bars"] = "計時條",
	["Setup bar animation options and scaling."] = "設定計時條外觀",
	["Bar Groups"] = "計時條群組",
	["Setup Bar Groups"] = "設定計時條群組",
	["Filters"] = "過濾器",
	["Filter different spell types."] = "過濾不同的技能類型",
	["Self"] = "自己", -- aka "player"
	["Which group should self casts be sent."] = "自身施法發送至哪個群組",
	["Buffs"] = "Buffs",
	["Which group should buffs be sent."] = "Buff發送到哪個群组",
	["Debuffs"] = "Debuffs",
	["Which group should debuffs be sent."] = "Debuff發送到哪個群组",
	["Cooldowns"] = "技能冷卻",
	["Which group should cooldowns be sent."] = "技能冷卻發送到哪個群組",
	["Target"] = "目標",
	["Which group should current target be sent."] = "目前目標發送到哪個群組",
	["Focus"] = "焦點",
	["Which group should focus be sent."] = "焦點目標發送到哪個群組",
	["Lock timer bars"] = "鎖定計時條",
	["Lock the position of the timer bars."] = "鎖定計時條的位置",
	["Reset Bars"] = "重置計時條",
	["Reset the posion of the bars."] = "重置計時條的位置",
	["Test Bars"] = "測試計時條",
	["Create sample reminder bars to test your layout."] = "建立一個樣本計時條去測試你的設定",
	["Bar Formatting"] = "計時條格式",
	["Various formating options for the bars."] = "設定計時條格式",
	["Icon Border"] = "圖示邊框",
	["Show a border on the icon."] = "顯示圖示邊框",
	["Display Text"] = "顯示文字",
	["Set the format of the text that appears on the bars.  Possible values are: %n (spell name) %r (spell rank) %t (target) %a (applications)"] = "設定計時條裡文字顯示的格式. 常用參數: %n (技能名) %r (技能等級) %t (目標) %a (動作)",
	["Texture"] = "材質",
	["Set the Bar Texture"] = "設定材質",
	["Bar Width"] = "寬度",
	["Set the Bar Width"] = "設定計時條寬度",
	["Bar Height"] = "高度",
	["Set the Bar Height"] = "設定計時條高度",
	["Font"] = "字型",
	["Set the Bar Font"] = "設定計時條字型",
	["Font Size"] = "字型大小",
	["Set the Cast Bar Font Size"] = "設定計時條字型大小",
	["Debug Mode"] = "除錯模式",
	["Show Debug Messages."] = "顯示除錯訊息",
	["Process Cooldowns"] = "技能冷卻計時",
	["Creates bars for spell cooldowns."] = "建立一個技能冷卻計時條",
	["Flash Bars"] = "閃爍計時條",
	["Flash bars when they are expiring."] = "當藥過期時閃爍計時條",
	["Text Warnings"] = "文字提醒",
	["Select which Text Warnings to display"] = "選擇文字提醒的方式",
	["Audiable Warnings"] = "音效提醒",
	["Play a sound when a spell is about to expire."] = "當技能到期時播放音效提醒",
	["Add New"] = "增加新的群組",  -- referring to bar group
	["Name of the new group."] = "新的群組名稱",
	["Setup Group"] = "設定群組",
	["Group Name"] = "群組名字",
	["Name of the Bar Group"] = "計時條群組的名稱",
	["Grow Upward"] = "向上延伸",
	["Bars stack ontop of each other instead of underneath each other."] = "計時氣向上延伸",
	["Reverse Sort"] = "反轉",
	["Sort timer bars in reverse."] = "反轉計時器",
	["Reset Position"] = "重置位置",
	["Reset group position to center."] = "重置位置到畫面中間",
	["Emphasise"] = "重要",
	["Bars from this group will emphasise."] = "這個群組的計時條被設定為重要",
	["Bar Scale"] = "計時條縮放",
	["Default Bar Scale."] = "預設縮放",
	["Delete"] = "刪除",
	["Delete this group"] = "刪除此群組",
	["Setup reminder for %s|nClick to %s"] = "設定提醒器為 %s|n點擊變更為 %s", -- spell name  ,  ("activate" or "deactivate")
	["activate"] = "啟用",
	["deactivate"] = "閒置",
	["Show Self"] = "顯示自己",
	["Show this spell if its cast on yourself."] = "顯示自己施放的",
	["Show Others"] = "顯示其他人",
	["Show this spell when its cast on others"] = "顯示其他人施放的",
	["Single Tracking"] = "單獨追蹤",
	["This will only track one instance of this spell at any one time.  Useful for Soulstone."] = "單獨追蹤一個技能",
	["Display Name"] = "顯示名字",
	["Spell name text to display on the bar. For example an abbreviation."] = "在計時條上顯示技能名稱",
	["Reminder"] = "提醒器",
	["Reminder occurs when the spell duration remaining reaches this value."] = "當計時持續時間到期時觸發提醒器",
	["Bar Color"] = "計時條顏色",
	["Set the color of the reminder bar."] = "設定計時條顏色",
	["Allow Custom Sound"] = "允許自訂音效",
	["Allow selection of a custom sound."] = "允許選擇自訂音效",
	["Custom Sound"] = "自訂音效",
	["Play a sound when a spell is about to expire."] = "當技能將要過期時播放音效",
	["Allow Custom Group"] = "允許自訂群組",
	["Allow selection of a custom destination group."] = "允許自訂群組",
	["Custom Group"] = "自定群組",
	["Which group should this spell be sent to."] = "技能發送到群組",
} end)































