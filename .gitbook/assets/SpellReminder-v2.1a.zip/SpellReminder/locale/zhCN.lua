local L = AceLibrary("AceLocale-2.2"):new("SpellReminder")
-- By wowui.cn & digmouse (merged by oridan)
L:RegisterTranslations("zhCN", function() return {
	-- core
	["None"] = "无",
	["Expiring Only"] = "仅监控即将消失的",
	["Expired Only"] = "仅监控已经消失的",
	["Both"] = "Both",
	
	[" Totem"] = "图腾", --  there's no space in Chinese
	[" Weapon"] = "武器", -- there's no space in Chinese
	
	["Detected new spell! (%s)"] = "检测到新的法术!(%s)", -- spell name

	["Normal"] = "普通",
	["Emphasis"] = "重要",
	
	["%s has had its custom group reset."] = "%s 已有了自定义的组.", -- spell name
	["Filter for '%s' has been reset."] = "'%s'过滤器已被重置", -- filter name
	["You should reload your UI after deleting a bar group."] = "删除一个计时条组后你必须重置你的插件",
	
	["%s over in %d seconds!"] = "%s 将在 %d 秒后消失!", -- bar name ,  seconds
	["%s has EXPIRED!"] = "%s 已过期", -- bar name

	["Filter Priorities"] = "过滤器优先级",
	["Set priorities for the filters."] = "设置过滤器的优先级",
	["Increase the priority of this filter."] = "增加过滤器的优先级",
	["Highest Priority"] = "最高优先级",
	["Lowest Priority"] = "最低优先级",
	
	-- options
	["Click a spell to stop tracking."] = "点击一个法术停止监测.",
	["Options for SpellReminder."] = "SpellReminder选项",
	["Spell Setup"] = "法术设置",
	["Setup spell reminders."] = "设置法术过期提醒",
	["Inactive"] = "不活动",
	["Inactive Spells"] = "不活动的法术",
	["Disable Detection"] = "禁用探测",
	["Disables the detection of new spells."] = "禁用探测新法术",
	["Default Bar Color"] = "默认计时条颜色",
	["Set the default color of the reminder bars."] = "设置默认计时条颜色",
	["Clear All Spells"] = "清除所有法术",
	["Will force SpellReminder to forget all options for ALL spells, including detected spells and pet spells."] = "强制清除所有法术到期提醒的配置",
	["Clear Inactive Spells"] = "清除不活动的法术",
	["Will force SpellReminder to forget all options for inactive spells."] = "强制清除所有不活动的法术",
	["Timer Bars"] = "计时条",
	["Setup bar animation options and scaling."] = "设置计时条外观",
	["Bar Groups"] = "计时条组",
	["Setup Bar Groups"] = "设置计时条组",
	["Filters"] = "过滤器",
	["Filter different spell types."] = "过滤不同的法术类型",
	["Self"] = "自身", -- aka "player"
	["Which group should self casts be sent."] = "自身施法发送到组",
	["Buffs"] = "Buffs",
	["Which group should buffs be sent."] = "Buff发送到组",
	["Debuffs"] = "Debuffs",
	["Which group should debuffs be sent."] = "Debuff发送到组",
	["Cooldowns"] = "冷却",
	["Which group should cooldowns be sent."] = "冷却发送到组",
	["Target"] = "目标",
	["Which group should current target be sent."] = "当前目标发送到组",
	["Focus"] = "焦点",
	["Which group should focus be sent."] = "焦点目标发送到组",
	["Lock timer bars"] = "锁定计时条",
	["Lock the position of the timer bars."] = "锁定计时条",
	["Reset Bars"] = "重置计时条",
	["Reset the posion of the bars."] = "重置计时条",
	["Test Bars"] = "测试计时条",
	["Create sample reminder bars to test your layout."] = "测试计时条",
	["Bar Formatting"] = "计时条样式",
	["Various formating options for the bars."] = "设置计时条样式",
	["Icon Border"] = "图标边框",
	["Show a border on the icon."] = "显示图标边框",
	["Display Text"] = "显示文字",
	["Set the format of the text that appears on the bars.  Possible values are: %n (spell name) %r (spell rank) %t (target) %a (applications)"] = "设置计时条里文字显示的格式. 常用参数: %n (法术名) %r (法术等级) %t (目标) %a (动作)",
	["Texture"] = "材质",
	["Set the Bar Texture"] = "设置材质",
	["Bar Width"] = "宽度",
	["Set the Bar Width"] = "设置计时条宽度",
	["Bar Height"] = "高度",
	["Set the Bar Height"] = "设置计时条高度",
	["Font"] = "字体",
	["Set the Bar Font"] = "设置计时条字体",
	["Font Size"] = "字体大小",
	["Set the Cast Bar Font Size"] = "设置计时条字体大小",
	["Debug Mode"] = "Debug模式",
	["Show Debug Messages."] = "显示Debug信息",
	["Process Cooldowns"] = "法术冷却计时",
	["Creates bars for spell cooldowns."] = "建立一个法术冷却计时条",
	["Flash Bars"] = "闪动计时条",
	["Flash bars when they are expiring."] = "当将要过期时闪动计时条",
	["Text Warnings"] = "文字提醒",
	["Select which Text Warnings to display"] = "选择文字提醒的方式",
	["Audiable Warnings"] = "声音提醒",
	["Play a sound when a spell is about to expire."] = "当法术到期播放声音提醒",
	["Add New"] = "增加",  -- referring to bar group
	["Name of the new group."] = "新的组名字",
	["Setup Group"] = "设置组",
	["Group Name"] = "组名字",
	["Name of the Bar Group"] = "计时条组的名字",
	["Grow Upward"] = "向上增长",
	["Bars stack ontop of each other instead of underneath each other."] = "计时器堆叠向上增长",
	["Reverse Sort"] = "反转",
	["Sort timer bars in reverse."] = "反转计时器",
	["Reset Position"] = "重置位置",
	["Reset group position to center."] = "重置位置到屏幕中间",
	["Emphasise"] = "重要",
	["Bars from this group will emphasise."] = "这个组的计时条被设置为重要",
	["Bar Scale"] = "计时条缩放",
	["Default Bar Scale."] = "默认缩放",
	["Delete"] = "删除",
	["Delete this group"] = "删除此组",
	["Setup reminder for %s|nClick to %s"] = "设置提醒器为%s|n点击更改为%s", -- spell name  ,  ("activate" or "deactivate")
	["activate"] = "激活",
	["deactivate"] = "未激活",
	["Show Self"] = "显示自身",
	["Show this spell if its cast on yourself."] = "显示自身施放的",
	["Show Others"] = "显示他人",
	["Show this spell when its cast on others"] = "显示他人施放的",
	["Single Tracking"] = "单独跟踪",
	["This will only track one instance of this spell at any one time.  Useful for Soulstone."] = "单独跟踪一个法术",
	["Display Name"] = "显示名字",
	["Spell name text to display on the bar. For example an abbreviation."] = "是否在计时条上显示法术名",
	["Reminder"] = "提醒器",
	["Reminder occurs when the spell duration remaining reaches this value."] = "当法术持续时间到达这个值时触发提醒器",
	["Bar Color"] = "计时条颜色",
	["Set the color of the reminder bar."] = "设置计时条颜色",
	["Allow Custom Sound"] = "允许自定义声音",
	["Allow selection of a custom sound."] = "允许自定义声音",
	["Custom Sound"] = "自定义声音",
	["Play a sound when a spell is about to expire."] = "当法术将要过期时播放声音",
	["Allow Custom Group"] = "允许自定义组",
	["Allow selection of a custom destination group."] = "允许自定义组",
	["Custom Group"] = "自定义组",
	["Which group should this spell be sent to."] = "法术发送到组",
} end)































