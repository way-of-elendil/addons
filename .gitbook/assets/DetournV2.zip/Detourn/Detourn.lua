﻿local version=2;
local table={};
local itable=1;
local unitname=UnitName("player");
local name,vers;
local vers_max=0;

function Detourn_OnEvent(self, event, ...)
	if(event=="COMBAT_LOG_EVENT_UNFILTERED") then
	local timestamp,type,sourceGUID,sourceName,sourceFlags,destGUID,destName,destFlags,spellId,spellName,spellSchool= select(1, ...);
			if(type=="SPELL_CAST_SUCCESS" and det_activ=="true") then
			--print("test ",spellId,spellName);
				if(spellId==34477 or spellId==57934) then
					local det_text= "Detourn:  "..sourceName.." ----> "..destName;
				 	
					if (UnitInRaid("player") and det_broad=="true")then
                        SendChatMessage(det_text,"RAID");
                    elseif (GetNumPartyMembers()>0 and det_broad=="true") then
                        SendChatMessage(det_text,"PARTY");
                    elseif (not (GetNumPartyMembers()>0) and not (UnitInRaid("player")))then
                        DEFAULT_CHAT_FRAME:AddMessage (det_text);
                        
                    end
				end
			end
					
	end
    if(event=="CHAT_MSG_ADDON") then
		local pref,mess,from= select(1, ...);
       
        if (pref=="DET_update") then
        --- initialisation ----
        table = {};
        itable=1;
        vers_max=0;
        if (det_activ=="true") then
        SendAddonMessage("DET_ver", unitname..":"..version, "RAID");
        end
        --print ("Det_update : "..mess);
        end
       
        if (pref=="DET_ver") then
            vers,name=cut(mess,":")
            vers=string.byte(vers);
            if (vers>vers_max) then 
                ----- nouvelle version reset de la liste, puis ajout------
                vers_max=vers;
                table = {};
                itable=1;
                --print (name.." a une nouvelle");
              table[itable]=name;
              itable = itable +1;
            elseif (vers==vers_max) then
               -------meme version que la liste actuelle , ajout---
               --print (name.." a une version actuelle");
               table[itable]=name;
              itable = itable +1;
            else 
               ----- ancienne version , passe-----
               --print (name.." a une version ancienne");
               end
        --table[itable] = mess;
        --print ("Det_ver : "..mess);
        end
        
    end    
end

function Detourn_OnLoad()
        print("Detourn activé");
	Detourn:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
    Detourn:RegisterEvent("CHAT_MSG_ADDON");
    
	SLASH_DETOURN1 = "/det";
	SLASH_DETOURN2 = "/detourn";
	SlashCmdList["DETOURN"] = Detourn_Command;
    Loadvar();
end

function Detourn_Command(msg)
	local cmd, subCmd = Detourn_GetCmd(msg);
	if(cmd=="on") then
			det_activ="true";
			print("|cccccccFFDetourn|r - has been |cff00ff00enabled|r.");
    elseif  (cmd=="off") then   
        	det_activ="false";
			print("|cccccccFFDetourn|r - has been |cffff0000disabled|r.");
	elseif(cmd=="test") then
        print("|cccccccFFDetourn|r - test' ")
	else
		print("|cccccccFFDetourn|r - Commands :\n \\det on  of \\det off for |cff00ff00activate|r or |cffff0000desactivate|r this add on ");
	end
    
end

function Detourn_GetCmd(msg)
	if(msg) then
		local a,b,c = strfind(msg, "(%S+)");
		if(a) then
			return c, strsub(msg, b+2);
		else	
			return "";
		end
	end
end

function Loadvar(self)
    if(det_activ==nil) then
	    det_activ="true";
    end
    if(det_broad==nil) then
	    det_broad="true";
    end
end   


Detourn_UpdateInterval = 1;
Detourn_UpdatePhase = 0;
function Detourn_OnUpdate(self, elapsed)
  self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed; 	

  if (self.TimeSinceLastUpdate > Detourn_UpdateInterval) then
    --
    -- Insert your OnUpdate code here
    --
   --print(" test ");
   if (mod(Detourn_UpdatePhase,2)==0) then
   --print("|cff00ff00Det: envoi|r");
   SendAddonMessage("DET_update", "Det: update", "RAID");
   else
   --print("|cffff0000Det: election|r");
   election();
   end
   Detourn_UpdatePhase=Detourn_UpdatePhase+1;
   self.TimeSinceLastUpdate = 0;
  end
end


function cut(ftext,fcursor)
local find=string.find(ftext,fcursor);
return string.sub(ftext, find+1),string.sub(ftext, 0,find-1);
end

function election()
    local winner= 0;
    for i=1,itable-1 do 
        --print(table[i]);
        local number_table = "";
            for x=1,strlen(table[i]) do
                number_table = number_table..string.byte(table[i],x);
            end
         local number_winner = "";
            for x=1,strlen(winner) do
                number_winner = number_winner..string.byte(winner,x);
            end   
                        
        if (number_table>number_winner) then 
        winner =table[i];
        end
        
    end
    --print("winner : "..winner);
    if ( unitname==winner ) then
    --print("iamthewinner");

    det_broad="true";
    else
    --print("ohnon");
    det_broad="false";
    end
end


