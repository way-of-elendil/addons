--new color coding
MYBARCOLORS =  {
	[1] = {r = 0.8, g = 0, b = 0},
	[2] = {r = 0.8, g = 0.3, b = 0.22},
	[3] = {r = 0.75, g = 0.27, b = 0},
	[4] = {r = 0.9, g = 0.7, b = 0},
	[5] = {r = 0, g = 1.0, b = 0.5},
	[6] = {r = 0, g = 0.5, b = 0.5},
	[7] = {r = 0, g = 0.5, b = 1.0},
	[8] = {r = 0.2, g = 0.7, b = 0.7},
};

-- labels
TITAN_REPUTATION_ALL_HIDDEN_LABEL = "Reputation: Off";
TITAN_REPUTATION_NO_FACTION_LABEL = "Reputation: No Faction Selected";
TITAN_REPUTATION_SHOW_FACTION_NAME_LABEL = "Show Faction Name";
TITAN_REPUTATION_SHOW_STANDING = "Show Standing";
TITAN_REPUTATION_SHOW_VALUE = "Show Reputatuion Value";
TITAN_REPUTATION_SHOW_PERCENT = "Show Percent";
TITAN_REPUTATION_AUTO_CHANGE = "Auto Show Changed";
TITAN_REPUTATION_SHOW_EXHALTED = "Show Exhalted";
TITAN_REPUTATION_SHOW_REVERED = "Show Revered";
TITAN_REPUTATION_SHOW_HONORED = "Show Honored";
TITAN_REPUTATION_SHOW_FRIENDLY = "Show Friendly";
TITAN_REPUTATION_SHOW_NEUTRAL = "Show Neutral";
TITAN_REPUTATION_SHOW_UNFRIENDLY = "Show Unfriendly";
TITAN_REPUTATION_SHOW_HOSTILE = "Show Hostile";
TITAN_REPUTATION_SHOW_HATED = "Show Hated";

-- globals
TITAN_REPUTATION_ID =  "Reputation";
TITAN_REPUTATION_VERSION = "3.0 (By Sol)";
TITAN_REPUTATION_BUTTON_ICON = "Interface\\AddOns\\TitanReputation\\TitanReputation";
TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_NO_FACTION_LABEL;

-- local
local TITAN_REPUTATION_TOOLTIP_TEXT = "";
local TITAN_REPUTATION_TABLE = {};
local TITAN_REPUTATION_CHANGEDFACTION = "none";
local TITAN_REPUTATION_EXALTED_COLOR = {r = 0.2, g = 0.7, b = 0.7};


-- initializing
function TitanPanelReputationButton_OnLoad(self)
	self.registry = {
		id = TITAN_REPUTATION_ID,
		menuText = TITAN_REPUTATION_ID, 
		version = TITAN_REPUTATION_VERSION,
		buttonTextFunction = "TitanPanelReputation_GetButtonText", 
		tooltipTitle = TITAN_REPUTATION_ID.." "..TITAN_REPUTATION_VERSION,
		tooltipTextFunction = "TitanPanelReputation_GetToolTipText", 
		category = "Information",
		icon = TITAN_REPUTATION_BUTTON_ICON,
		iconWidth = 16,
		savedVariables = {
			ShowIcon = 1,
			ShowFactionName = 1,
			ShowStanding = 1,
			ShowValue = 1,
			ShowPercent = 1, 
			AutoChange = 1,
			TITAN_REPUTATION_WATCHED_FACTION = "none",
			ShowExhalted = 1,
			ShowRevered= 1,
			ShowHonored= 1,
			ShowFriendly= 1,
			ShowNeutral= 1,
			ShowUnfriendly= 1,
			ShowHostile= 1,
			ShowHated= 1,
		}
	};	
    self:RegisterEvent("UPDATE_FACTION");
end

-- event handling
function TitanPanelReputationButton_OnClick(self, button)
     if (button == "LeftButton") then
	     ToggleCharacter("ReputationFrame");
     end
     if (button == "RightButton") then
	     TitanPanelRightClickMenu_PrepareReputationMenu(self);
     end
end

function TitanPanelReputationButton_OnEvent()	
	TITAN_REPUTATION_CHANGEDFACTION = "none";
	TitanPanelReputation_GatherFactions(TitanPanelReputation_GetChangedName);
	if(TitanGetVar(TITAN_REPUTATION_ID, "AutoChange")) then
		if(not (TITAN_REPUTATION_CHANGEDFACTION == "none")) then
			TitanSetVar(TITAN_REPUTATION_ID, "TITAN_REPUTATION_WATCHED_FACTION", TITAN_REPUTATION_CHANGEDFACTION);
		end		
	end
	TitanPanelReputation_GatherFactions(TitanPanelReputation_GatherValues);
	TitanPanelReputation_Refresh();
	TitanPanelButton_UpdateTooltip();
	TitanPanelButton_UpdateButton(TITAN_REPUTATION_ID);
end

-- for titan to get the displayed text
function TitanPanelReputation_GetButtonText(id)
	TitanPanelReputation_Refresh();
	return TITAN_REPUTATION_BUTTON_TEXT;
end

-- for titan tool tip text building
function TitanPanelReputation_GetToolTipText()
	TITAN_REPUTATION_TOOLTIP_TEXT = "";
	TitanPanelReputation_GatherFactions(TitanPanelReputation_BuildToolTipText);
	return TITAN_REPUTATION_TOOLTIP_TEXT;
end

-- this method adds a line to the tooltip text
function TitanPanelReputation_BuildToolTipText(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	local showrep = 0;
	local TotalExhalted = 0;

	if(isInactive) then
		showrep = 0;
	else
		showrep = 1;
	end

	if(isHeader) then
		if (not isCollapsed) then 
			TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT.."\n"..TitanUtils_GetHighlightText(name).."\n"; 
		end

		if(name == "Horde Expedition" or name == "Alliance Vanguard") then
			showrep = 1;
		else
			showrep = 0;
		end
	end
	
	if(showrep == 1) then
		showrep = 0;

		if(standingId == 8 and TitanGetVar(TITAN_REPUTATION_ID, "ShowExhalted")) then showrep = 1; end
		if(standingId == 7 and TitanGetVar(TITAN_REPUTATION_ID, "ShowRevered")) then showrep = 1; end
		if(standingId == 6 and TitanGetVar(TITAN_REPUTATION_ID, "ShowHonored")) then showrep = 1; end
		if(standingId == 5 and TitanGetVar(TITAN_REPUTATION_ID, "ShowFriendly")) then showrep = 1; end
		if(standingId == 4 and TitanGetVar(TITAN_REPUTATION_ID, "ShowNeutral")) then showrep = 1; end
		if(standingId == 3 and TitanGetVar(TITAN_REPUTATION_ID, "ShowUnfriendly")) then showrep = 1; end
		if(standingId == 2 and TitanGetVar(TITAN_REPUTATION_ID, "ShowHostile")) then showrep = 1; end
		if(standingId == 1 and TitanGetVar(TITAN_REPUTATION_ID, "ShowHated")) then showrep = 1; end

		if(showrep == 1) then
			if(standingId == 8) then
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetHighlightText(" -"); 
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetColoredText(name, TITAN_REPUTATION_EXALTED_COLOR).."\t";			
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetColoredText(getglobal("FACTION_STANDING_LABEL"..standingId),TITAN_REPUTATION_EXALTED_COLOR).."\n";			
			else
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetHighlightText(" -"); 
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetColoredText(name, MYBARCOLORS[standingId]).." - ";			
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetColoredText(getglobal("FACTION_STANDING_LABEL"..standingId),MYBARCOLORS[standingId]).."\t";
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT.."["..TitanUtils_GetColoredText(earnedValue.."/"..topValue, MYBARCOLORS[standingId]).."] ";
				TITAN_REPUTATION_TOOLTIP_TEXT = TITAN_REPUTATION_TOOLTIP_TEXT..TitanUtils_GetColoredText(percent.."%",MYBARCOLORS[standingId]).."\n";
			end
		end	
	end
end

-- this method builds the right-click menus
function TitanPanelRightClickMenu_PrepareReputationMenu()
	-- level 2 menus
	if ( UIDROPDOWNMENU_MENU_LEVEL == 2 ) then
		TitanPanelRightClickMenu_AddTitle(UIDROPDOWNMENU_MENU_VALUE, UIDROPDOWNMENU_MENU_LEVEL);
		TitanPanelReputation_GatherFactions(TitanPanelReputation_BuildFactionSubMenu);
		return;
	end
	-- level 1 menu
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[TITAN_REPUTATION_ID].menuText.." v"..TITAN_REPUTATION_VERSION);
	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelReputation_GatherFactions(TitanPanelReputation_BuildRightClickMenu);
	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelRightClickMenu_AddToggleIcon(TITAN_REPUTATION_ID);
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_FACTION_NAME_LABEL, TITAN_REPUTATION_ID, "ShowFactionName");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_STANDING, TITAN_REPUTATION_ID, "ShowStanding");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_VALUE, TITAN_REPUTATION_ID, "ShowValue");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_PERCENT, TITAN_REPUTATION_ID, "ShowPercent");	
	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_EXHALTED, TITAN_REPUTATION_ID, "ShowExhalted");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_REVERED, TITAN_REPUTATION_ID, "ShowRevered");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_HONORED, TITAN_REPUTATION_ID, "ShowHonored");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_FRIENDLY, TITAN_REPUTATION_ID, "ShowFriendly");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_NEUTRAL, TITAN_REPUTATION_ID, "ShowNeutral");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_UNFRIENDLY, TITAN_REPUTATION_ID, "ShowUnfriendly");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_HOSTILE, TITAN_REPUTATION_ID, "ShowHostile");	
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_SHOW_HATED, TITAN_REPUTATION_ID, "ShowHated");	
	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelRightClickMenu_AddToggleVar(TITAN_REPUTATION_AUTO_CHANGE, TITAN_REPUTATION_ID, "AutoChange");	
end

-- this method adds a line to the right-click menu (to build up faction headers)
function TitanPanelReputation_BuildRightClickMenu(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	if(not isInactive) then
		if(isHeader and not isCollapsed) then
			command = {}
			command.text = name;
			command.value = name;
			command.hasArrow = 1;
			UIDropDownMenu_AddButton(command);
		end
	end
end

-- this method adds a line to the level2 right-click menu (to build up factions for parent header)
function TitanPanelReputation_BuildFactionSubMenu(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	if(parentName == UIDROPDOWNMENU_MENU_VALUE and (not isHeader or (name == "Horde Expedition" or name == "Alliance Vanguard"))) then
		command = {}
		command.text = name;
		command.value = name;
		command.func = TitanPanelReputation_SetFaction;
		UIDropDownMenu_AddButton(command, UIDROPDOWNMENU_MENU_LEVEL);
	end
end

-- this method sets the selected faction shown at titan panel
function TitanPanelReputation_SetFaction()
		TitanSetVar(TITAN_REPUTATION_ID, "TITAN_REPUTATION_WATCHED_FACTION", this.value);
		TitanPanelReputation_Refresh();
		TitanPanelButton_UpdateButton(TITAN_REPUTATION_ID);
end

-- This method refreshes the reputation data
function TitanPanelReputation_Refresh()
	if not (TitanGetVar(TITAN_REPUTATION_ID, "TITAN_REPUTATION_WATCHED_FACTION") == "none") then
		TitanPanelReputation_GatherFactions(TitanPanelReputation_BuildButtonText);
	else
		TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_NO_FACTION_LABEL;		
	end
end

-- This method sets the text of the button according to selected faction's data
function TitanPanelReputation_BuildButtonText(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	if((not isHeader or (name == "Horde Expedition" or name == "Alliance Vanguard")) and (TitanGetVar(TITAN_REPUTATION_ID, "TITAN_REPUTATION_WATCHED_FACTION")==name)) then
		TITAN_REPUTATION_BUTTON_TEXT = "";
		local COLOR = MYBARCOLORS[standingId];
		if(standingId == 8) then
			COLOR = TITAN_REPUTATION_EXALTED_COLOR;
		end		
		if(TitanGetVar(TITAN_REPUTATION_ID, "ShowFactionName")) then TITAN_REPUTATION_BUTTON_TEXT = TitanUtils_GetColoredText(name, COLOR).." - "; end;
		if(TitanGetVar(TITAN_REPUTATION_ID, "ShowStanding")) then TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_BUTTON_TEXT..TitanUtils_GetColoredText(getglobal("FACTION_STANDING_LABEL"..standingId),COLOR).." "; end;
		if(TitanGetVar(TITAN_REPUTATION_ID, "ShowValue")) then TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_BUTTON_TEXT.."["..TitanUtils_GetColoredText(earnedValue.."/"..topValue, COLOR).."] "; end;
		if(TitanGetVar(TITAN_REPUTATION_ID, "ShowPercent")) then TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_BUTTON_TEXT..TitanUtils_GetColoredText(percent.."%",COLOR); end;
		if(not (TitanGetVar(TITAN_REPUTATION_ID, "ShowFactionName") or TitanGetVar(TITAN_REPUTATION_ID, "ShowStanding") or TitanGetVar(TITAN_REPUTATION_ID, "ShowValue") or TitanGetVar(TITAN_REPUTATION_ID, "ShowPercent"))) then
			TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_BUTTON_TEXT..TITAN_REPUTATION_ALL_HIDDEN_LABEL;
		end
		TITAN_REPUTATION_BUTTON_TEXT = TITAN_REPUTATION_BUTTON_TEXT.."\n";
	end
end

-- saves all reputation value, so we can monitor what is changed
function TitanPanelReputation_GatherValues(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	if(not isHeader and name) then
		TITAN_REPUTATION_TABLE[name] = {};
		TITAN_REPUTATION_TABLE[name].standingId = standingId;
		TITAN_REPUTATION_TABLE[name].earnedValue = earnedValue;
	end
end

-- gets the faction name where reputation changed
function TitanPanelReputation_GetChangedName(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, isInactive)
	if(TITAN_REPUTATION_TABLE[name]) then
		if((TITAN_REPUTATION_TABLE[name].standingId < standingId) or (TITAN_REPUTATION_TABLE[name].earnedValue < earnedValue)) then
			if(TITAN_REPUTATION_CHANGEDFACTION == "none") then TITAN_REPUTATION_CHANGEDFACTION = name; end;
		end
	end
end

-- This method looks up all factions, and calls 'method' with faction parameters
function TitanPanelReputation_GatherFactions(method)
		local count = GetNumFactions();
		local done = false;
		local index = 1;
		local parentName = "";
		while(not done)do
			local name, description, standingId, bottomValue, topValue, earnedValue, atWarWith,
			canToggleAtWar, isHeader, isCollapsed, isWatched = GetFactionInfo(index);
			local value;
			-- Normalize values
			topValue = topValue - bottomValue;
			earnedValue = earnedValue - bottomValue;
			bottomValue = 0;
			percent = format("%.2f",(earnedValue/topValue)*100);
			if(percent:len()<5) then percent = "0"..percent; end;
			if(isHeader) then parentName = name; end;
			method(name, parentName, standingId, topValue, earnedValue, percent, isHeader, isCollapsed, IsFactionInactive(index));
			index = index+1;
			if(index>count) then done = true; end;
		end		
end
